module.exports = {
  HEALTH_CHECK: {},
  AUTH: {
    alreadyExists: "User already exists",
    notFound: "User not found",
    invalidCredentials: "Invalid credentials",
    invalidToken: "Invalid or expired refresh token",
  },
  CONTENT: {},
  FEEDBACK: {},
  CONTACT_US: {},
};
