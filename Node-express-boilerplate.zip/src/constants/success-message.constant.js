module.exports = {
  HEALTH_CHECK: {
    getAppHealth: true,
  },
  AUTH: {
    register: "User registered successfully",
    login: "Login successful",
    refreshToken: "Token refreshed successfully",
  },
  FEEDBACK: {
    createFeedback:
      "Thank you for your feedback! We appreciate your time and effort in helping us improve.",
  },
  CONTACT_US: {
    createContactUs:
      "Thank you for reaching out! Your request has been successfully submitted. We will get back to you shortly.",
  },
};
