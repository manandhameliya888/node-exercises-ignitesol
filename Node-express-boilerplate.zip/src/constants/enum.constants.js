const CONTENT_TYPE = {
  CODE: "CODE",
  TEXT: "TEXT",
};

module.exports = { CONTENT_TYPE };
