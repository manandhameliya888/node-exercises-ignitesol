const Joi = require("joi");

const createContactUs = {
  body: Joi.object().keys({
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    description: Joi.string().required(),
    email: Joi.string().email().required(),
    phoneNumber: Joi.string()
      .optional()
      .allow("")
      .pattern(/^\+?[1-9]\d{1,14}$/)
      .message("Invalid phone number format"),
  }),
};

module.exports = {
  createContactUs,
};
