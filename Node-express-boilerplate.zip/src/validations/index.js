module.exports.authValidation = require("./auth.validation");
module.exports.feedbackValidation = require("./feedback.validation");
module.exports.contactUsValidation = require("./contact-us.validation");
