const Joi = require("joi");

const createFeedback = {
  body: Joi.object().keys({
    name: Joi.string().required(),
    experience: Joi.string().required(),
    email: Joi.string().email().required(),
    review: Joi.number().min(1).max(5).required(),
  }),
};

module.exports = {
  createFeedback,
};
