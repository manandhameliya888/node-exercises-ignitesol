const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { SUCCESS_MESSAGE, ERROR_MESSAGE } = require("../constants");
const { User } = require("../models");

const generateToken = (user, expiresIn) => {
  return jwt.sign({ id: user._id, email: user.email }, process.env.JWT_SECRET, {
    expiresIn,
  });
};

module.exports = {
  register: async (requestObject) => {
    const { body } = requestObject;
    const { name, email, password } = body;

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return { message: ERROR_MESSAGE.AUTH.alreadyExists, body: null };
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = (
      await User.create({
        name,
        email,
        password: hashedPassword,
      })
    ).toObject();

    delete newUser.password;

    const accessToken = generateToken(newUser, "1h");
    const refreshToken = generateToken(newUser, "7d");

    return {
      message: SUCCESS_MESSAGE.AUTH.register,
      data: {
        user: newUser,
        access_token: accessToken,
        refresh_token: refreshToken,
      },
    };
  },

  login: async (requestObject) => {
    const { body } = requestObject;
    const { email, password } = body;

    const user = await User.findOne({ email }).lean();
    if (!user) {
      return { message: ERROR_MESSAGE.AUTH.notFound, body: null };
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return { message: ERROR_MESSAGE.AUTH.invalidCredentials, body: null };
    }

    const accessToken = generateToken(user, "1h");
    const refreshToken = generateToken(user, "7d");
    delete user.password;

    return {
      message: SUCCESS_MESSAGE.AUTH.login,
      data: { user, access_token: accessToken, refresh_token: refreshToken },
    };
  },

  refreshToken: async (requestObject) => {
    const { body } = requestObject;
    const { refresh_token } = body;

    try {
      const decoded = jwt.verify(refresh_token, process.env.JWT_SECRET);

      const user = await User.findById(decoded.id);
      if (!user) {
        return { message: ERROR_MESSAGE.AUTH.notFound, body: null };
      }

      const newAccessToken = generateToken(user, "1h");
      const newRefreshToken = generateToken(user, "7d");

      return {
        message: SUCCESS_MESSAGE.AUTH.refreshToken,
        data: { access_token: newAccessToken, refresh_token: newRefreshToken },
      };
    } catch {
      return { message: ERROR_MESSAGE.AUTH.invalidToken, body: null };
    }
  },
};
