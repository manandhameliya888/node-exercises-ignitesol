module.exports = {
  info: async () => {
    return {
      message: "User fetched successfully",
      body: {
        user: {},
      },
    };
  },
};
