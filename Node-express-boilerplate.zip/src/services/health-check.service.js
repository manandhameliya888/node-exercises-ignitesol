const { SUCCESS_MESSAGE } = require("../constants");

module.exports = {
  getAppHealth: async () => {
    return { runing: SUCCESS_MESSAGE.HEALTH_CHECK.getAppHealth };
  },
};
