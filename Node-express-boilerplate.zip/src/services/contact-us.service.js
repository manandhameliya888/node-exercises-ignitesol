const { SUCCESS_MESSAGE } = require("../constants");
const { Contact_Us } = require("../models");

module.exports = {
  createContactUs: async (requestObject) => {
    const { body } = requestObject;
    await Contact_Us.create(body);
    return { message: SUCCESS_MESSAGE.CONTACT_US.createContactUs };
  },
};
