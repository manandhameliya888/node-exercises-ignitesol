const { SUCCESS_MESSAGE } = require("../constants");
const { Feedback } = require("../models");

module.exports = {
  createFeedback: async (requestObject) => {
    const { body } = requestObject;
    await Feedback.create(body);
    return { message: SUCCESS_MESSAGE.FEEDBACK.createFeedback };
  },
};
