const mongoose = require("mongoose");
const validator = require("validator");
const { toJSON, paginate } = require("./plugins");

const Contact_UsSchema = mongoose.Schema(
  {
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    description: { type: String, required: true },
    email: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      validate(value) {
        if (!validator.isEmail(value)) {
          throw new Error("Invalid email");
        }
      },
    },
    phoneNumber: {
      type: String,
      required: false,
      trim: true,
      lowercase: true,
      validate(value) {
        if (value && !validator.isMobilePhone(value)) {
          throw new Error("Invalid phone number");
        }
      },
    },
  },
  { timestamps: true },
);

// add plugin that converts mongoose to json
Contact_UsSchema.plugin(toJSON);
Contact_UsSchema.plugin(paginate);

/**
 * @typedef Contact_Us
 */
const Contact_Us = mongoose.model("Contact_Us", Contact_UsSchema);

module.exports = Contact_Us;
