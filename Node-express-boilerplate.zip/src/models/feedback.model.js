const mongoose = require("mongoose");
const validator = require("validator");
const { toJSON, paginate } = require("./plugins");

const FeedbackSchema = mongoose.Schema(
  {
    name: { type: String, required: true },
    experience: { type: String, required: true },
    email: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      validate(value) {
        if (!validator.isEmail(value)) {
          throw new Error("Invalid email");
        }
      },
    },
    review: {
      type: Number,
      required: true,
      validate(value) {
        if (value < 1 || value > 5) {
          throw new Error("Review must be between 1 and 5 stars.");
        }
      },
    },
  },
  { timestamps: true },
);

// add plugin that converts mongoose to json
FeedbackSchema.plugin(toJSON);
FeedbackSchema.plugin(paginate);

/**
 * @typedef Feedback
 */
const Feedback = mongoose.model("Feedback", FeedbackSchema);

module.exports = Feedback;

// Contact US
// firstName: string
// lastName: string
// email: string
// phoneNumber: string
// description: string
