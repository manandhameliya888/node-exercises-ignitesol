require("dotenv").config();
const mongoose = require("mongoose");
const app = require("./app");
const logger = require("./config/logger");
const RedisClient = require("./config/redis"); // Import Redis client

let server;

// MongoDB connection
mongoose
  .connect(process.env.DATABASE_URL)
  .then(() => {
    logger.info("Connected to MongoDB");
    server = app.listen(process.env.PORT, () => {
      logger.info(`Listening to port ${process.env.PORT}`);
    });
  })
  .catch((error) => {
    logger.error("Error connecting to MongoDB:", error);
    process.exit(1);
  });

// Redis connection
const redisClient = RedisClient.redisClient;

const exitHandler = () => {
  if (server) {
    server.close(() => {
      logger.info("Server closed");
      process.exit(1);
    });
  } else {
    process.exit(1);
  }
  if (redisClient && redisClient.isConnected) {
    redisClient.quit(() => {
      logger.info("Redis client disconnected");
    });
  }
};

const unexpectedErrorHandler = (error) => {
  logger.error(error);
  exitHandler();
};

process.on("uncaughtException", unexpectedErrorHandler);
process.on("unhandledRejection", unexpectedErrorHandler);

process.on("SIGTERM", () => {
  logger.info("SIGTERM received");
  if (server) {
    server.close();
  }
});
