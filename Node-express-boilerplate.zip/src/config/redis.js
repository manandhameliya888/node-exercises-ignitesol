const Redis = require("ioredis");
const logger = require("./logger");

class RedisClient {
  redisClient = null;
  isConnected = false;

  constructor() {
    this.redisClient = new Redis({
      port: Number(process.env.REDIS_PORT),
      host: process.env.REDIS_HOST,
      username: process.env.REDIS_USERNAME,
      password: process.env.REDIS_PASSWORD,
      connectTimeout: Number(process.env.REDIS_CONNECTION_TIMEOUT) || 86400,
    });

    this.redisClient.on("connect", () => {
      this.isConnected = true;
      logger.info("Connected to Redis");
    });

    this.redisClient.on("error", (err) => {
      logger.error("Error connecting to Redis:", err);
    });
  }
}

module.exports = new RedisClient();
