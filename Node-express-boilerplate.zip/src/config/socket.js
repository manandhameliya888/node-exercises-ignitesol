const { Server } = require("socket.io");
const socketHandlers = require("../socket/handlers");
const { socketService } = require("../services");

const initializeSocket = (server) => {
  const io = new Server(server, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"],
    },
  });

  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);
    socketService.addSocket(socket.id);

    // Register socket event handlers
    socketHandlers(io, socket);

    socket.on("disconnect", () => {
      console.log("User disconnected:", socket.id);
      socketService.removeSocket(socket.id);
    });
  });

  return io;
};

module.exports = initializeSocket;
