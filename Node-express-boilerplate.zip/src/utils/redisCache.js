const RedisClient = require("../config/redis");

class RedisHelper {
  static isConnected() {
    return RedisClient.isConnected;
  }

  static async storeKeyValue(key, data, expiry = 0) {
    if (!this.isConnected()) {
      throw new Error("Redis is not connected");
    }
    const value = JSON.stringify(data);
    if (expiry > 0) {
      await RedisClient.redisClient.set(key, value, "EX", expiry);
    } else {
      await RedisClient.redisClient.set(key, value);
    }
  }

  /**
   * Update the value of an existing Redis key with an optional expiry time.
   * @param {string} key - The Redis key to update.
   * @param {any} data - The new data to store (automatically stringified).
   * @param {number} expiry - Expiry time in seconds (optional).
   */
  static async updateKeyValue(key, data, expiry = 0) {
    if (!this.isConnected()) {
      throw new Error("Redis is not connected");
    }
    const exists = await RedisClient.redisClient.exists(key);
    if (!exists) {
      throw new Error(`Key "${key}" does not exist`);
    }
    const value = JSON.stringify(data);
    if (expiry > 0) {
      await RedisClient.redisClient.set(key, value, "EX", expiry);
    } else {
      await RedisClient.redisClient.set(key, value);
    }
  }

  /**
   * Get the value of a Redis key.
   * @param {string} key - The Redis key.
   * @returns {Promise<any>} - The parsed value of the key, or null if not found.
   */
  static async getKeyValue(key) {
    if (!this.isConnected()) {
      throw new Error("Redis is not connected");
    }
    const value = await RedisClient.redisClient.get(key);
    return value ? JSON.parse(value) : null;
  }

  /**
   * Delete a Redis key.
   * @param {string} key - The Redis key to delete.
   * @returns {Promise<number>} - The number of keys that were deleted (0 or 1).
   */
  static async deleteKey(key) {
    if (!this.isConnected()) {
      throw new Error("Redis is not connected");
    }
    return await RedisClient.redisClient.del(key);
  }
}

module.exports = RedisHelper;
