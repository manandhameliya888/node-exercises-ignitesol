const express = require("express");
const http = require("http");
const cors = require("cors");
const swaggerJSDoc = require("swagger-jsdoc");
const swaggerUi = require("swagger-ui-express");
const httpStatus = require("http-status");
const routes = require("./routes");
const { errorConverter, errorHandler } = require("./middlewares/error");
const ApiError = require("./utils/ApiError");
const swaggerDefinition = require("./swagger.json");
const logger = require("./config/logger");
const initializeSocket = require("./config/socket");
require("./cron/keepServerActive.cron");

const app = express();
const server = http.createServer(app);

// Initialize Socket.IO
initializeSocket(server);

app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));
app.use(cors());
app.options("*", cors());

// Logging middleware
app.use((req, res, next) => {
  if (!req.originalUrl.startsWith("/docs/")) {
    logger.info(`${req.method}: ${req.originalUrl}`);
  }
  next();
});

// APIs
app.use("/", routes);

// Swagger
const swaggerSpec = swaggerJSDoc({
  swaggerDefinition,
  apis: ["./routes/*.js"],
});
app.use("/docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));

// Handler
app.use((req, res, next) => next(new ApiError(httpStatus.NOT_FOUND, "API Not found")));
app.use((err, req, res, next) => {
  if (err.type === "entity.too.large") {
    res.status(413).send({
      message: "Payload too large. Please reduce the size of your request body.",
    });
  } else {
    next(err);
  }
});
app.use(errorConverter);
app.use(errorHandler);

module.exports = server;
