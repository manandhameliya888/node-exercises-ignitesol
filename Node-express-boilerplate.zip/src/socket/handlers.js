const socketHandlers = (io, socket) => {
  // Join room based on routeCode
  socket.on("join", async () => {
    // ------------------------
  });

  // Handle content updates
  socket.on("update", async () => {
    // ------------------------
  });
  
  // Handle disconnection
  socket.on("disconnect", () => {
    // ------------------------
  });
};

module.exports = socketHandlers;
