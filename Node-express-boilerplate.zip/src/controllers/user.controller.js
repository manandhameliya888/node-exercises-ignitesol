const httpStatus = require("http-status");
const catchAsync = require("../utils/catchAsync");
const { userService } = require("../services");

const info = catchAsync(async (req, res) => {
  const response = await userService.info();
  res.status(httpStatus.OK).send(response);
});

module.exports = {
  info,
};
