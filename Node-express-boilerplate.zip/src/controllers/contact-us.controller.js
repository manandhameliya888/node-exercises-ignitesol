const httpStatus = require("http-status");
const catchAsync = require("../utils/catchAsync");
const { contactUsService } = require("../services");

const createContactUs = catchAsync(async (req, res) => {
  const requestObject = { body: req.body };
  const response = await contactUsService.createContactUs(requestObject);
  res.status(httpStatus.CREATED).send(response);
});

module.exports = {
  createContactUs,
};
