const httpStatus = require("http-status");
const catchAsync = require("../utils/catchAsync");
const { feedbackService } = require("../services");

const createFeedback = catchAsync(async (req, res) => {
  const requestObject = { body: req.body };
  const response = await feedbackService.createFeedback(requestObject);
  res.status(httpStatus.CREATED).send(response);
});

module.exports = {
  createFeedback,
};
