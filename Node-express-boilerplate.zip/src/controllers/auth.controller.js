const httpStatus = require("http-status");
const catchAsync = require("../utils/catchAsync");
const { authService } = require("../services");

const register = catchAsync(async (req, res) => {
  const requestObject = { body: req.body };
  const response = await authService.register(requestObject);
  res.status(httpStatus.OK).send(response);
});

const login = catchAsync(async (req, res) => {
  const requestObject = { body: req.body };
  const response = await authService.login(requestObject);
  res.status(httpStatus.OK).send(response);
});

const refreshToken = catchAsync(async (req, res) => {
  const requestObject = { body: req.body };
  const response = await authService.refreshToken(requestObject);
  res.status(httpStatus.OK).send(response);
});

module.exports = {
  register,
  login,
  refreshToken,
};
