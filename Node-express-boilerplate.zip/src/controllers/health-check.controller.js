const httpStatus = require("http-status");
const catchAsync = require("../utils/catchAsync");
const { healthCheckService } = require("../services");

const getAppHealth = catchAsync(async (req, res) => {
  const response = await healthCheckService.getAppHealth();
  res.status(httpStatus.OK).send(response);
});


module.exports = {
  getAppHealth,
};
