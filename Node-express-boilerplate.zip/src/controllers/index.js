module.exports.healthCheckController = require("./health-check.controller");
module.exports.authController = require("./auth.controller");
module.exports.userController = require("./user.controller");
module.exports.feedbackController = require("./feedback.controller");
module.exports.contactUsController = require("./contact-us.controller");
