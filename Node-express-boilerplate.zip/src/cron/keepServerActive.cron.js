const nodecron = require("node-cron");
const logger = require("../config/logger");
const { Content } = require("../models");

nodecron.schedule(
  "*/10 * * * *", // Runs every 10 minutes
  async () => {
    const contentCount = await Content.countDocuments();
    logger.info(`=> Total number of content URLs: ${contentCount}`);
  },
  {
    scheduled: true,
    timezone: "Asia/Seoul",
  },
);
