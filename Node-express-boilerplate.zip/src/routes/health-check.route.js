const express = require("express");
const { healthCheckController } = require("../controllers");

const router = express.Router();

router.route("/").get(healthCheckController.getAppHealth);

module.exports = router;
