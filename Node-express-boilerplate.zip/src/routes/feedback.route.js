const express = require("express");
const validate = require("../middlewares/validate");
const { feedbackValidation } = require("../validations");
const { feedbackController } = require("../controllers");

const router = express.Router();

router.route("/").post(validate(feedbackValidation.createFeedback), feedbackController.createFeedback);

module.exports = router;
