const express = require("express");
const healthCheckRoute = require("./health-check.route");
const authRoute = require("./auth.route");
const userRoute = require("./user.route");
const feedbackRoute = require("./feedback.route");
const contactUsRoute = require("./contact-us.route");
const router = express.Router();

const defaultRoutes = [
  {
    path: "/health-check",
    route: healthCheckRoute,
  },
  {
    path: "/auth",
    route: authRoute,
  },
  {
    path: "/user",
    route: userRoute,
  },
  {
    path: "/feedback",
    route: feedbackRoute,
  },
  {
    path: "/contact-us",
    route: contactUsRoute,
  },
];

defaultRoutes.forEach((route) => {
  router.use(route.path, route.route);
});

module.exports = router;
