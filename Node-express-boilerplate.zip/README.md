# GET-MY-CODE Backend

### Installation

To install the required dependencies, run the following command:

```bash
npm install
```

### Environment Variables

Set the required environment variables before starting the server.

### Start the Server

To start the development server, use the command:

```bash
npm run dev
```

### Pre-commit

Before committing changes, run the following command to fix any issues:

```bash
npm run lint
```

Server will start on `http://localhost:3000`

## REST APIs

### Health Check
- **GET** `/health`
  - Returns: `{ status: true }`

### Socket Statistics
- **GET** `/health/sockets`
  - Returns: `{ activeSockets: string[], totalConnections: number }`

### Get Document
- **GET** `/documents/:routeCode`
  - Returns: `{ routeCode: string, content: string }`

## Socket.IO Events

### Connecting to Socket
```javascript
const socket = io('http://localhost:3000');
```

### Join Document Room
```javascript
// Event: 'join'
// Description: Join a specific document room to receive updates
socket.emit('join', 'your-route-code');

// Response: 'initialContent'
socket.on('initialContent', (data) => {
  // data: { routeCode: string, content: string }
  console.log('Initial content:', data);
});
```

### Update Document Content
```javascript
// Event: 'update'
// Description: Send updates to document content
socket.emit('update', {
  routeCode: 'your-route-code',
  contentData: 'Updated document content'
});

// Response: 'contentUpdated'
socket.on('contentUpdated', (data) => {
  // data: { routeCode: string, content: string }
  console.log('Content updated:', data);
});
```

### Error Handling
```javascript
socket.on('error', (error) => {
  console.error('Socket error:', error);
});
```

## Example Usage

```javascript
// Connect to socket
const socket = io('http://localhost:3000');

// Join a document room
socket.emit('join', { routeCode: 'doc123' });

// Listen for other users joining
socket.on('userJoined', (data) => {
  console.log('New user joined the document:', data.socketId);
});

// Listen for initial content
socket.on('initialContent', (data) => {
  console.log('Received initial content:', data.content);
});

// Listen for updates
socket.on('contentUpdated', (data) => {
  console.log('Document updated:', data.content);
});

// Send an update
socket.emit('update', {
  routeCode: 'doc123',
  contentData: 'Hello, World!'
});

// Event: 'userLeft'
socket.on('userLeft', (data) => {
  // data: { socketId: string, timestamp: Date, remainingUsers: number }
  console.log('User left:', data);
});

// Handle errors
socket.on('error', (error) => {
  console.error('Error:', error.message);
});
```

## Data Structures

### Document Object
```typescript
{
  routeCode: string;  // Unique identifier for the document
  content: string;    // Document content
}
```

## Error Handling

The socket will emit an 'error' event in case of:
- Failed to join a room
- Failed to update content
- Database errors

## Real-time Collaboration

When multiple users are connected to the same document (same routeCode):
1. All users join the same room via the 'join' event
2. When any user updates content:
   - Changes are saved to MongoDB
   - All users in the room receive the 'contentUpdated' event
   - Updates are synchronized across all connected clients
